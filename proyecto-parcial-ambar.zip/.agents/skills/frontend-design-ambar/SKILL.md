---
name: frontend-design-ambar
description: Use when creating, redesigning, or reviewing a web interface for Ambar Cocina Experimental, or when the user asks for a distinctive, non-generic UI in React + Vite + Tailwind. Use before writing UI code, not after.
---

# Frontend Design - Ambar

This is an original, Ambar-specific adaptation of the frontend-design idea: avoid generic AI interfaces by deciding direction before code. It is not a copy of Anthropic's official frontend-design skill. For the official skill, clone https://github.com/anthropics/skills and copy only `skills/frontend-design/`.

## 1. Decide before coding

Before writing any JSX, answer in one line each:

1. **Purpose:** Who uses this screen and what must they complete in under a minute?
2. **Tone:** Editorial high-end gastronomy (Étage reference), restrained, architectural, tactile. Monolithic black `#101010` and off-white bone `#F3F3F3` blocks with deep bordeaux `#6F1D1B` accent. Not playful, not corporate SaaS, not neon esports, no floating glassmorphism.
3. **Constraints:** React 18, Vite, Tailwind CSS, React Router. No new dependency without a reason.
4. **Differentiation:** What would make this screen recognisably Ambar and not interchangeable with any restaurant template?

If any answer is vague, ask for it or propose one and label it as a proposal. Do not start with a generic hero + cards layout.

## 2. Ambar design system (closed)

Use these exact literal hex values. Do not invent a new palette per page or rely on removed token aliases.

- **Bordeaux `#6F1D1B`** - primary accent, action buttons, active tabs, selected states, fine accent borders. Meets WCAG $\ge 4.5:1$ contrast against `#F3F3F3`.
- **Near-black `#101010`** - dominant dark background, solid header, monolithic sidebar, administrative login, and full-bleed hero backdrop.
- **Bone white `#F3F3F3`** - dominant light canvas for technical reservation sheets, dashboard metrics, and administrative data tables.
- **Neutral gray `#919191`** - secondary supporting text, metadata, and timestamps **ONLY over dark `#101010` backgrounds** (meets $\ge 4.5:1$ contrast). **NEVER use `#919191` for small text over `#F3F3F3`**, as it fails WCAG AA minimum contrast.
- **Headings & Monumental Branding:** Old Standard TT (`font-serif-classic`), classical high-contrast serif with Georgia as system fallback.
- **Body, UI & Form Controls:** Golos Text (`font-golos`), geometric and legible sans-serif.
- **Metrics, Times, Codes, Capacities & IDs:** Monospace (`font-mono`).
- **Font Loading:** Verify that Old Standard TT and Golos Text are loaded in `index.html` via Google Fonts with `preconnect`.
- **Geometry & Corners:** Refined rectangular lines (`rounded-none` or `rounded-sm`), fine dividers (`border-[#101010]/20` on light or `border-[#F3F3F3]/15` on dark). No pill buttons or `rounded-3xl` containers.

## 3. Forbidden generic patterns

Do not use, unless the user explicitly asks for them:

- Pill buttons (`rounded-full`) or capsule badges everywhere.
- White floating cards with soft diffuse drop-shadows and glassmorphism backdrop-blur on light backgrounds.
- Centred hero with two pill buttons, three identical cards, and a generic footer.
- Purple/blue gradients on white backgrounds.
- Inter, Roboto, Arial, system fonts, or Space Grotesk as the default choice.
- `Modal.jsx` or `Button.jsx` as reusable components: **they have been removed from the project**; do not import or propose them.
- Emoji as icons - use Lucide icons as SVG with `aria-hidden="true"`.
- Placeholder lorem ipsum in any deliverable.

## 4. Composition

- Alternating full-bleed blocks: high-contrast alternation between bone white `#F3F3F3` and near-black `#101010`.
- Typographic tension: massive classical serif titles paired with compact uppercase monospace data tags and sober Golos Text body.
- Omnipresent reservation system: repeated actionable entry points (hero, narrative dividers, footer) rather than an isolated CTA.
- Transitions: crisp and swift (150-200 ms). Interactive elements must include `cursor-pointer` and an explicit focus ring (`focus:outline-none focus:ring-2 focus:ring-[#6F1D1B] focus:ring-offset-2`).
- Operational state vs. error: a sold-out slot is an operational state, not an error. Display "Agotado (4/4 mesas)" with the rationale, and visibly offer the next available slot.
- Background video integration: decorative background videos must have `autoPlay`, `muted`, `loop`, `playsInline`, `preload="auto"`, `aria-hidden="true"`, `pointer-events-none`, a dark overlay (`bg-black/65` to `bg-black/70`) for contrast, and respect `prefers-reduced-motion` with an image poster fallback.

## 5. Output format for Ambar

Deliver, in this order:

1. The one-line direction chosen (purpose, tone, differentiation).
2. Three distinct directions, or one direction with three concrete variations, and name which one is the most generic and why it is rejected.
3. The chosen system: colours, type scale, spacing, and component states (default, hover, active, disabled, focus).
4. Only then, the code or the art direction, reusing existing components where they exist.
5. **Rubric lock (Candado de rúbrica):** If any design decision or skill recommendation conflicts with the project rubric or evaluation requirements, **the rubric always wins**. State the conflict explicitly to the user; never alter evaluation criteria in silence.

Do not claim a component is reusable if it is not imported anywhere. Check imports before describing the system.

## 6. Ambar business rules to respect

- **Capacity & Exclusivity:** Strict maximum of 4 tables per time slot and maximum 16 guests per slot. Both limits govern real-time availability.
- **Party Size:** Guest options range from 1 to 8 comensales, explicitly including 7 (`[1, 2, 3, 4, 5, 6, 7, 8]`).
- **Table Occupancy:** Pending reservations **do occupy a table**; cancelled reservations **free a table** and do not count toward density or daily KPI counts.
- **Capacity Validation on Reactivation:** Reactivating a reservation from `cancelled` to `confirmed` or `pending` is **only permitted if the slot has at least 1 free table and sufficient remaining seats** (`remainingSeats >= reservation.guests`). If capacity is full, the action is blocked with an accessible message (`role="alert"`: "Sin aforo disponible en ese turno") without altering the reservation.
- **Demo Prototype Anchor:** Prototype dates are anchored to **30 Oct 2026**, including the sold-out slot at 19:30 (4/4 tables, 12 comensales) with next free slot at 20:00. Do not switch "today" to real-time date in prototype code so dashboard KPIs do not drop to zero.
- **Simulated Admin Guard:** Administrative access uses a simulated session guard stored in `sessionStorage` (`ambar_admin_session = 'authenticated'`) with demo credentials `admin / admin123`. It is not real authentication and must display a visible notice.
- **Rubric Overrides Skill:** If this skill ever conflicts with the academic rubric or business rules, the rubric strictly prevails.
