---
name: ambar-accessibility-check
description: Use when reviewing or fixing an Ambar web interface for accessibility and UI quality, or when the user asks for a WCAG check, a contrast check, or a form and keyboard review. Use after UI code exists, and report findings as file:line.
---

# Ambar Accessibility Check

A focused checklist adapted from Vercel's Web Interface Guidelines and WCAG 2.1 AA. It does not replace a manual test with keyboard and screen reader, but it catches the failures most often missed under time pressure.

## Checklist

Check each item and report it as `file:line - problem - fix`. Do not report "looks accessible" without checking the items below.

1. **Labels are associated:** Every input has a `label` with `htmlFor` matching the input `id`, or an equivalent accessible name. A visual text block above an input is not a label.
2. **Interactive elements are real controls:** Clickable cards, experiences, and zones must be `<button>` elements or have a correct role, keyboard handling, and focus style. A `div` with only `onClick` fails keyboard navigation.
3. **Focus is visible:** Every interactive element shows a visible focus state. Do not remove outlines without replacing them.
4. **Keyboard path:** The whole flow can be completed with Tab, Enter, Space, and arrow keys where applicable. Test: date strip, time slots, guest selector, form, and admin table actions.
5. **Contrast:** Text and UI controls meet at least 4.5:1 for normal text. Check Ambar pairs explicitly, for example accent `#A55704` on cream `#F8EADC` and cream on dark `#09251C`, and do not assume a brand colour passes.
6. **Colour is not the only signal:** Status (confirmed, pending, cancelled) and errors must not rely on colour alone. Use text, icon, or shape as well.
7. **Semantic structure:** One main heading hierarchy, semantic landmarks (`header`, `main`, `nav`), and a table with a proper `thead` where tabular data is shown.
8. **Form errors:** Errors are announced in text near the field, not only by a red border, and they appear after touch/submit, not only on submit with no field message.
9. **Reduced motion and touch targets:** Respect reduced-motion preferences where animation is used, and keep touch targets comfortably tappable on mobile.
10. **No fake success states:** A success screen must not invent a reservation if the navigation state is lost on refresh. Redirect to the booking flow instead of showing a placeholder voucher.

## Ambar failures already known (verify they are fixed, do not re-report them as new)

- `ReservationForm.jsx`: labels without `htmlFor`/`id`, and experience / zone selectors built as clickable `div` elements.
- `BookingWizard.jsx`: check that `useEffect` is imported before trusting any collision warning in the UI.
- `CalendarGrid.jsx`: density and counts must exclude cancelled reservations, or the calendar will contradict availability.

## Output format

1. Critical failures first (keyboard blockers, missing labels, fake states)
2. Then contrast and semantic issues
3. Then minor polish
4. End with what was actually checked: files reviewed, and what still needs a manual keyboard / screen-reader pass
